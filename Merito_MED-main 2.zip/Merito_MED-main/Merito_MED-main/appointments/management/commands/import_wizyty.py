from django.core.management.base import BaseCommand
from appointments.models import Wizyta
from datetime import datetime

class Command(BaseCommand):
    help = 'Importuje dane wizyt z pliku CSV'

    def handle(self, *args, **kwargs):
        with open('media/wizyty.csv', newline='', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                Wizyta.objects.create(
                    miasto=row['miasto'],
                    specjalizacja=row['specjalizacjia'],
                    imie_i_nazwisko=row['imie i nazwisko'],
                    data=datetime.strptime(row['data'], "%Y-%m-%d").date(),
                    godzina=datetime.strptime(row['godzina'], "%H:%M").time()
                )
        self.stdout.write(self.style.SUCCESS('Dane zostały zaimportowane!'))